 // Your web app's Firebase configuration
 var firebaseConfig = {
    apiKey: "AIzaSyC7qRexfvh-EDvNuT0wdjpQp0LSKG_num8",
    authDomain: "fir-webapp-72631.firebaseapp.com",
    databaseURL: "https://fir-webapp-72631.firebaseio.com",
    projectId: "fir-webapp-72631",
    storageBucket: "fir-webapp-72631.appspot.com",
    messagingSenderId: "446353254020",
    appId: "1:446353254020:web:94cb738b650c34765584d1",
    measurementId: "G-HP0N0WR2FP"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);

  firebase.auth.Auth.Persistence.LOCAL;

  $("#btn-signup").click(function(){

    var email = $("#email").val();
    var password = $("#password").val();
    var cPassword = $("#confirmPassword").val();
      
    if(email != "" && password != "" && cPassword != "")
      {
        if(password == cPassword)
        {
                var result = firebase.auth().createUserWithEmailAndPassword(email, password);
            result.catch(function(error)
            {
                var errorCode = error.code;
                var errorMessage = error.message
                
                console.log(errorCode);
                console.log(errorMessage);
                window.alert("Message : " + errorMessage);
            });
        }
        else
        {
          window.alert("Le mot de passe ne correspondent pas à la confirmation du mot de passe");

        }
      }
      else
      {
          window.alert("Le formulaire est incomplet. Veuillez remplir tous les champs");
      }
  });
  
  $("#btn-login").click(function(){

    var email = $("#email").val();
    var password = $("#password").val();
      
    if(email != "" && password != "")
      {
        var result = firebase.auth().signInWithEmailAndPassword(email, password);
        result.catch(function(error)
        {
            var errorCode = error.code;
            var errorMessage = error.message
            
            console.log(errorCode);
            console.log(errorMessage);
            window.alert("Message : " + errorMessage);
        });
      }
      else
      {
          window.alert("Le formulaire est incomplet. Veuillez remplir tous les champs.")
      }
  });

  $("#btn-resetPassword").click(function(){

    var auth = firebase.auth();
    var email =  $("#email").val()

    if(email != "")
    {
      auth.sendPasswordResetEmail(email).then(function()
      {
        window.alert("Un e-mail vous a été envoyé, veuillez vérifier et vérifier.");
      })
      .catch(function(error)
      {
        var errorCode = error.code;
        var errorMessage = error.message
        
        console.log(errorCode);
        console.log(errorMessage);
        window.alert("Message : " + errorMessage);
      });
    }
    else
    {
        window.alert("Veuillez d'abord écrire votre e-mail.")

    }
   });

   $("#btn-update").click(function()
   {
      var phone = $("#phone").val();
      var address = $("#address").val();
      var bio = $("#bio").val();
      var fName = $("#firstName").val();
      var sName = $("#secondName").val();
      var country = $("#country").val();
      var gender = $("#gender").val();

      var rootRef = firebase.database().ref().child("Users");
      var userID = firebase.auth().currentUser.uid;
      var usersRef = rootRef.child(userID);

       if(fName!="" && sName!="" && phone!="" && country!="" && gender!="" && bio!="" && address!="")
       {
         var userData = 
         {
             "phone"      : phone,
             "address"    : address,
             "bio"        : bio,
             "firstName"  : fName,
             "secondName" : sName,
             "country"    : country,
             "gender"     : gender,
         } ;
         usersRef.set(userData, function(error)
         {
             if(error)
             {
                var errorCode = error.code;
                var errorMessage = error.message
        
                console.log(errorCode);
                console.log(errorMessage);
                window.alert("Message : " + errorMessage);
             }
             else
             {
               window.location.href = "home.html";
             }
         });
       }
       else
       {
         window.alert("Le formulaire est incomplet. Veuillez remplir tous les champs.");
       }

   });

  $("#btn-logout").click(function(){

   firebase.auth().signOut();
  });

  function switchView(view) 
  {
    $.get({
      url:view,
      cache:false,
    })
    .then(function(data)
    {
      $("#container").html(data);
    });
  }